package Embedding;

import java.util.List;

public class Word2Vec implements Generate{
    @Override
    public void generateEmbedding(List<String> walks){

    }
}
