package Embedding;

import java.util.List;

interface Generate {
    public void generateEmbedding(List<String> walks);
}
