### 此软件包用于生成五分图的SourceEmbedding,可以针对多数据源
#### 五分图有平面图和竖图构成。
#### 其中平面图由tuple, a(i), source构成
#### 竖图有a'(i), a'(ij), A(i)构成
#### ps: tuple为元组，source为数据源，a'(i)为单个表的一行
#### a'(ij)为a'(i)中的每个单元格中的数值, A(i)为属性
#### 上述均定义为String类型进行表示