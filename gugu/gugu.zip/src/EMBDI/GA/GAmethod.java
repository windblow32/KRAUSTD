package EMBDI.GA;

public class GAmethod {
    public void Hello(){

    }
}
